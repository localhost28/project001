A Pen created at CodePen.io. You can find this one at http://codepen.io/Tushkiz/pen/xqfsy.

 Simple Login Form with Flat UI